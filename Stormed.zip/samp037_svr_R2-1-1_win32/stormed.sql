-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2022 at 09:38 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stormed`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(25) NOT NULL,
  `PASSWORD` varchar(65) NOT NULL,
  `EMAIL` varchar(65) NOT NULL,
  `GENDER` int(11) NOT NULL,
  `AGE` int(11) NOT NULL,
  `SKIN` int(11) NOT NULL DEFAULT 250,
  `ADMIN` int(11) NOT NULL,
  `HELPER` int(11) NOT NULL,
  `CASH` int(11) NOT NULL,
  `BANK` int(11) NOT NULL,
  `BYTECOINS` int(11) NOT NULL,
  `LEVEL` int(11) NOT NULL,
  `PREMIUM` int(11) NOT NULL,
  `PREMIUMPOINTS` int(11) NOT NULL,
  `VIP` int(11) NOT NULL,
  `HOUSE` int(11) NOT NULL,
  `BUSINESS` int(11) NOT NULL,
  `SPAWNX` float NOT NULL,
  `SPAWNY` float NOT NULL,
  `SPAWNZ` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `houses`
--

CREATE TABLE `houses` (
  `ID` int(11) NOT NULL,
  `OWNER` varchar(25) NOT NULL DEFAULT 'The State',
  `DESCRIPTION` varchar(25) NOT NULL DEFAULT 'None',
  `INTERIOR` int(11) NOT NULL,
  `PRICE` int(11) NOT NULL,
  `RENTPRICE` int(11) NOT NULL,
  `RENTERS` int(11) NOT NULL,
  `SAFE` int(11) NOT NULL,
  `STATUS` int(11) NOT NULL,
  `OWNERSQLID` int(11) NOT NULL,
  `X` float NOT NULL,
  `Y` float NOT NULL,
  `Z` float NOT NULL,
  `EXITX` float NOT NULL,
  `EXITY` float NOT NULL,
  `EXITZ` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `kick_logs`
--

CREATE TABLE `kick_logs` (
  `TEXT` varchar(150) NOT NULL DEFAULT '-',
  `DATE` varchar(10) NOT NULL DEFAULT '-',
  `TIME` varchar(8) NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `TEXT` varchar(150) NOT NULL DEFAULT '-',
  `DATE` varchar(10) NOT NULL DEFAULT '-',
  `TIME` varchar(8) NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `staff_chat`
--

CREATE TABLE `staff_chat` (
  `COMMAND` varchar(2) NOT NULL DEFAULT '-',
  `TEXT` varchar(150) NOT NULL DEFAULT '-',
  `DATE` varchar(10) NOT NULL DEFAULT '-',
  `TIME` varchar(8) NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `staff_logs`
--

CREATE TABLE `staff_logs` (
  `TEXT` varchar(150) NOT NULL DEFAULT '-',
  `DATE` varchar(10) NOT NULL DEFAULT '-',
  `TIME` varchar(8) NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `houses`
--
ALTER TABLE `houses`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
